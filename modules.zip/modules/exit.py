#!/usr/bin/env python3

import conf.conf as conf


def exit():
    conf.clear()
    conf.sys.exit()
    conf.ans = None
